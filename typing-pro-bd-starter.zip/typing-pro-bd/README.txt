TYPING PRO BD — Free demo starter

1. Extract this ZIP.
2. Open index.html in a browser to preview.
3. To publish free, create a GitHub account, create a public repository named typing-pro-bd, upload index.html, then enable Settings > Pages > Deploy from a branch > main > /(root).
4. Your public address will look like https://YOUR-USERNAME.github.io/typing-pro-bd/ (replace YOUR-USERNAME).

IMPORTANT:
- This is a front-end demo only. It does not create real accounts, save submissions to a server, calculate real earnings, or send money.
- Wallet and withdrawal are intentionally disabled.
- Never collect a user's bKash/Nagad/Rocket PIN or OTP.
- Before real launch, connect a secure backend (e.g. Firebase Authentication + Firestore with strict security rules), build admin-only review, publish genuine work sources, and define transparent payout terms.
- Do not advertise guaranteed income or accept deposits/registration fees.
